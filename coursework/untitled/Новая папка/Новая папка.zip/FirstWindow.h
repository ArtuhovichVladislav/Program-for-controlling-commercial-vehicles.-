#ifndef FIRSTWINDOW_H
#define FIRSTWINDOW_H

#include <QDialog>
#include <QPushButton>
#include <QWidget>
#include <QMessageBox>


class FirstWindow: public QDialog
{
    Q_OBJECT
public:
    FirstWindow(QWidget *parent);
private:
    QPushButton *about;
    QPushButton *startFile;
    QPushButton *exit;
private slots:
    void aboutClicked();
    void startClicked();
};

#endif // FIRSTWINDOW_H
