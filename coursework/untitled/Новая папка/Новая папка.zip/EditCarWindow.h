#ifndef EDITCARWINDOW_H
#define EDITCARWINDOW_H

#include <QWidget>
#include <QPushButton>
#include <QDialog>
#include <QComboBox>
#include <QLineEdit>
#include <QLabel>
#include "Cars.h"
#include "MainWindow.h"
#include "tree.cpp"

class MainWindow;

class EditCarWindow: public QDialog
{
    Q_OBJECT
public:
    EditCarWindow(MainWindow *mW, QWidget *parent, QString model);
private:
    MainWindow *mw;

    Wagon *wagon;
    Tipper *tipper;
    OilCar *oilCar;
    Refrigerator *refrig;
    QString carModel;

    QComboBox *carType;
    QComboBox *carCondition;
    QLineEdit *number;
    QLineEdit *driverSurname;
    QLineEdit *driverName;
    QLineEdit *driverPatronymic;

    QPushButton *edit;
    QPushButton *cancel;

    template <class TYPE>
    void setValue(TYPE *obj,QComboBox *cond, QLineEdit *num, QLineEdit *name, QLineEdit *sur, QLineEdit *patr);

    template <class TYPE>
    void insertValue(TYPE *obj, QString typeOfCar, QComboBox *type, QComboBox *cond, QLineEdit *num,  QLineEdit *name, QLineEdit *sur, QLineEdit *patr);
private slots:
    void editClicked();
    void cancelClicked();
    void setEditEnabled();
signals:
    void closed();
};
#endif // EDITCARWINDOW_H
