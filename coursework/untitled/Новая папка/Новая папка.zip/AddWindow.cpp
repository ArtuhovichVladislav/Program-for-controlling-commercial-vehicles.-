#include "AddWindow.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QMessageBox>

AddWindow::AddWindow(MainWindow *mW, QWidget *parent): QDialog(parent)
{
    mw = mW;
    QLabel *lbl0 = new QLabel("Выберите тип:");

    carType = new QComboBox();
    carType->addItem("Фургон");
    carType->addItem("Рефрижератор");
    carType->addItem("Самосвал");
    carType->addItem("Цистерна");

    QHBoxLayout *cb0 = new QHBoxLayout;
    cb0->addWidget(lbl0);
    cb0->addWidget(carType);

    QLabel *lbl = new QLabel("Введите марку:");
    carModel = new QLineEdit;
    carModel->setMaximumWidth(200);
    QHBoxLayout *cb = new QHBoxLayout;
    cb->addWidget(lbl);
    cb->addWidget(carModel);

    wagonSpec = new QComboBox();
    refrigSpec = new QComboBox();
    tipperSpec = new QComboBox();
    oilSpec = new QComboBox();

    wagonLbl = new QLabel("Вид фургона:");
    for(int i =0; i < 2; i++)
        wagonSpec->addItem(wagon.getType(i));
    refrigLbl = new QLabel("Температурный диапазон:");
    for(int i=0; i<3; i++)
        refrigSpec->addItem(refrig.getTempDiap(i));
    tipperLbl = new QLabel("Вид самосвала:");
    for(int i=0; i<3; i++)
        tipperSpec->addItem(tipper.getType(i));
    oilLbl = new QLabel("Вид цистерны:");
    for(int i=0; i<3; i++)
        oilSpec->addItem(oilCar.getType(i));
    tipperLbl->hide();
    refrigLbl->hide();
    oilLbl->hide();
    refrigSpec->hide();
    tipperSpec->hide();
    oilSpec->hide();

    connect(carType,SIGNAL(currentTextChanged(QString)), this, SLOT(cbChanged()));

    QHBoxLayout *cbs = new QHBoxLayout;
    cbs->addWidget(wagonLbl);
    cbs->addWidget(refrigLbl);
    cbs->addWidget(tipperLbl);
    cbs->addWidget(oilLbl);
    cbs->addWidget(wagonSpec);
    cbs->addWidget(refrigSpec);
    cbs->addWidget(tipperSpec);
    cbs->addWidget(oilSpec);

    QLabel *lbl1 = new QLabel("Состояние:");
    carCondition = new QComboBox();
    for(int i=0; i<4; i++)
        carCondition->addItem(wagon.getCondition(i));

    QHBoxLayout *cb1 = new QHBoxLayout;
    cb1->addWidget(lbl1);
    cb1->addWidget(carCondition);

    QLabel *lbl2 = new QLabel("Регистрационный номер: ");
    carRegion = new QComboBox();
    for(int i=1; i<=7;i++)
        carRegion->addItem(QString::number(i));

    carNumber = new QLineEdit;
    carNumber->setMaxLength(4);
    carNumber->setMaximumWidth(100);
    carSym = new QLineEdit;
    carSym->setMaxLength(2);
    carSym->setMaximumWidth(50);
    QHBoxLayout *cb2 = new QHBoxLayout;
    cb2->addWidget(lbl2);
    cb2->addWidget(carNumber);
    cb2->addWidget(carSym);
    cb2->addWidget(carRegion);

    QLabel *lbl3 = new QLabel("Информация о водителе");

    QLabel *sur = new QLabel("Фамилия");
    driverSurname = new QLineEdit;
    driverSurname->setMaximumWidth(200);
    QHBoxLayout *cb3 = new QHBoxLayout;
    cb3->addWidget(sur);
    cb3->addWidget(driverSurname);

    QLabel *name = new QLabel("Имя");
    driverName = new QLineEdit;
    driverName->setMaximumWidth(200);
    QHBoxLayout *cb4 = new QHBoxLayout;
    cb4->addWidget(name);
    cb4->addWidget(driverName);

    QLabel *sname = new QLabel("Отчество");
    driverSecName = new QLineEdit;
    driverSecName->setMaximumWidth(200);
    QHBoxLayout *cb5 = new QHBoxLayout;
    cb5->addWidget(sname);
    cb5->addWidget(driverSecName);

    QVBoxLayout *drInfo = new QVBoxLayout;
    drInfo->addWidget(lbl3);
    drInfo->addLayout(cb3);
    drInfo->addLayout(cb4);
    drInfo->addLayout(cb5);

    ok = new QPushButton("Добавить");
    ok->setEnabled(false);
    cancel = new QPushButton("Отмена");
    QHBoxLayout *btns = new QHBoxLayout;
    btns->addWidget(ok);
    btns->addWidget(cancel);

    QVBoxLayout *res = new QVBoxLayout;
    res->addLayout(cb0);
    res->addLayout(cb);
    res->addLayout(cbs);
    res->addLayout(cb1);
    res->addLayout(cb2);
    res->addLayout(drInfo);
    res->addLayout(btns);
    setLayout(res);

    connect(carModel,SIGNAL(textChanged(QString)), this, SLOT(setOkEnabled()));
    connect(carNumber,SIGNAL(textChanged(QString)), this, SLOT(setOkEnabled()));
    connect(carSym,SIGNAL(textChanged(QString)), this, SLOT(setOkEnabled()));
    connect(carCondition,SIGNAL(currentTextChanged(QString)), this, SLOT(setOkEnabled()));
    connect(carCondition, SIGNAL(currentTextChanged(QString)), this, SLOT(setDisabled()));
    connect(driverSurname,SIGNAL(textChanged(QString)), this, SLOT(setOkEnabled()));
    connect(driverName,SIGNAL(textChanged(QString)), this, SLOT(setOkEnabled()));
    connect(driverSecName,SIGNAL(textChanged(QString)), this, SLOT(setOkEnabled()));
    connect(ok, SIGNAL(clicked()), this, SLOT(okClicked()));
    connect(cancel, SIGNAL(clicked()), this, SLOT(cancelClicked()));
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
    setWindowTitle("Добавить автомобиль");
    setWindowIcon(QIcon(":/Icons/icons/Add.png"));
}

void AddWindow::setOkEnabled()
{
    if((carModel->text().isEmpty())
            || driverName->text().isEmpty() || driverSurname->text().isEmpty()
            || driverSecName->text().isEmpty())
    {
        ok->setEnabled(false);
    }
    else
    {
        ok->setEnabled(true);
    }
    if(!carModel->text().isEmpty() && (carCondition->currentText() == "Списан"))
        ok->setEnabled(true);
}

void AddWindow::cbChanged()
{
    if(carType->currentText()=="Фургон")
    {
        wagonLbl->show();
        tipperLbl->hide();
        refrigLbl->hide();
        oilLbl->hide();
        wagonSpec->show();
        refrigSpec->hide();
        tipperSpec->hide();
        oilSpec->hide();
    }
    if(carType->currentText()=="Рефрижератор")
    {
        wagonLbl->hide();
        tipperLbl->hide();
        refrigLbl->show();
        oilLbl->hide();
        refrigSpec->show();
        wagonSpec->hide();
        tipperSpec->hide();
        oilSpec->hide();
    }
    if(carType->currentText()=="Самосвал")
    {
        wagonLbl->hide();
        tipperLbl->show();
        refrigLbl->hide();
        oilLbl->hide();
        tipperSpec->show();
        wagonSpec->hide();
        refrigSpec->hide();
        oilSpec->hide();
    }
    if(carType->currentText()=="Цистерна")
    {
        wagonLbl->hide();
        tipperLbl->hide();
        refrigLbl->hide();
        oilLbl->show();
        oilSpec->show();
        wagonSpec->hide();
        refrigSpec->hide();
        tipperSpec->hide();
    }
}

void AddWindow::okClicked()
{
    if(carType->currentText()=="Фургон")
    {
        setValue<Wagon>(&wagon, wagonSpec);
        undoAdd<Wagon>(wagon, 1);
        mw->wagonTree.createTree(wagon);
    }
    if(carType->currentText()=="Рефрижератор")
    {
        setValue<Refrigerator>(&refrig, refrigSpec);
        undoAdd<Refrigerator>(refrig, 2);
       /* undoStack *action;
        action = new undoStack(wasAdd, wagon.getModel());
        mw->undoDelWag.push(action);
        mw->wagonsForDel->push_back(wagon.getModel());
        mw->wagonActive();
        emit mw->stackChanged();
        mw->wagonTree.createTree(wagon);*/
        mw->refrigTree.createTree(refrig);
    }
    if(carType->currentText()=="Самосвал")
    {
        setValue<Tipper>(&tipper, tipperSpec);
        mw->tipperTree.createTree(tipper);
    }
    if(carType->currentText()=="Цистерна")
    {
        setValue<OilCar>(&oilCar, oilSpec);
        mw->oilTree.createTree(oilCar);
    }
    emit closed();
    this->close();
}

template <class TYPE>
void AddWindow::undoAdd(TYPE obj, int tab)
{
    undoStack *action;
    action = new undoStack(wasAdd, obj.getModel());

    if(tab == 1)
    {
        mw->undoDelWag.push(action);
        mw->wagonsForDel->push_back(obj.getModel());
        mw->wagonActive();
    }
    if(tab == 2)
    {
        mw->undoDelRefrig.push(action);
        mw->refrigForDel->push_back(obj.getModel());
        mw->refrigActive();
    }
    if(tab == 3)
    {
        mw->undoDelTipper.push(action);
        mw->tippersForDel->push_back(obj.getModel());
        mw->tipperActive();
    }
    if(tab == 4)
    {
        mw->undoDelOil.push(action);
        mw->oilCarsForDel->push_back(obj.getModel());
        mw->oilCarActive();
    }
    emit mw->stackChanged();
}

void AddWindow::cancelClicked()
{
    this->close();
}

template <class TYPE>
void AddWindow::setValue(TYPE *obj, QComboBox *objSpec)
{
    obj->setModel(carModel->text());
    obj->setType(objSpec->currentText());
    obj->setCondition(carCondition->currentText());
    obj->setNumber(carNumber->text()+carSym->text()+carRegion->currentText());
    obj->setName(driverName->text());
    obj->setSurname(driverSurname->text());
    obj->setPatronymic(driverSecName->text());
}
