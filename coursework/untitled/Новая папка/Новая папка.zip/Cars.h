#ifndef CARS_H
#define CARS_H
#include <iostream>
#include <QString>
#include "Driver.h"
#include <QDataStream>
using namespace std;

class Cars
{
protected:
    QString model;
//	CarType type;
    QString condition;
    QString number;
public:
	Cars();
    Cars(QString mod,QString cond, QString num);
    Cars(const Cars &temp);

    QString getModel();
    void setModel(QString newModel);

    QString getCondition();
    QString getCondition(int num);
    void setCondition(QString newCondition);

    QString getNumber();
    void setNumber(QString newNumber);

    bool operator <(Cars &car);
    bool operator >(Cars &car);
    bool operator ==(Cars &car);

	~Cars();
};


class Wagon: public Cars, public Driver
{
private:
    QString type;
public:
    Wagon();
    Wagon(QString model, QString cond, QString num, QString name, QString sur, QString patr, QString type1);
    QString getType();
    QString getType(int num);
    void setType(QString newType);

    friend QDataStream& operator >> (QDataStream& ds, Wagon &wagon);
    friend QDataStream& operator << (QDataStream& ds, Wagon &wagon);
};

class Refrigerator: public Cars, public Driver
{
private:
    QString tempDiap;
public:
    Refrigerator();
    Refrigerator(QString model, QString cond, QString num, QString name, QString sur, QString patr, QString tempdiap);
    QString getType();
    QString getTempDiap();
    QString getTempDiap(int num);
    void setTempDiap(QString newDiap);
    void setType(QString newDiap);
    friend QDataStream& operator >> (QDataStream& ds, Refrigerator &refrig);
    friend QDataStream& operator << (QDataStream& ds, Refrigerator &refrig);
};

class Tipper: public Cars, public Driver
{
private:
    QString type;
public:
    Tipper();
    Tipper(QString model, QString cond, QString num, QString name, QString sur, QString patr, QString type1);
    QString getType();
    QString getType(int num);
    void setType(QString newType);

    friend QDataStream& operator >> (QDataStream& ds, Tipper &tipper);
    friend QDataStream& operator << (QDataStream& ds, Tipper &tipper);
};

class OilCar: public Cars, public Driver
{
private:
    QString type;
public:
    OilCar();
    OilCar(QString model, QString cond, QString num, QString name, QString sur, QString patr, QString type1);
    QString getType();
    QString getType(int num);
    void setType(QString newType);
    friend QDataStream& operator >> (QDataStream& ds, OilCar &oilCar);
    friend QDataStream& operator << (QDataStream& ds, OilCar &oilCar);
};

#endif
