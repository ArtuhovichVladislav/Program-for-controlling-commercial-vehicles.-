#ifndef UNDOSTACK_H
#define UNDOSTACK_H

#include <QString>
using namespace std;

class undoStack
{
public:
    int actionCode;
    QString data;
    undoStack *next;
public:
    undoStack *head;
public:
    undoStack();
    undoStack(int actionCode, QString data);
    void push(undoStack *newAction);
    undoStack* pop();
    QString getData();
    int getActionCode();
    bool isEmpty();
};

#endif // UNDOSTACK_H
