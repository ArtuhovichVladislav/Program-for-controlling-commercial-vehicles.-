#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QWidget>
#include <QPushButton>
#include <QMenu>
#include <QDialog>
#include <QToolBar>
#include <QMenuBar>
#include <QComboBox>
#include <QLineEdit>
#include <QToolBar>
#include <QStatusBar>
#include <QMainWindow>
#include <QLabel>
#include <QCloseEvent>
#include <QStringList>
#include <QTextEdit>
#include "tree.cpp"
#include "Cars.h"
#include "AddWindow.h"
#include "EditCarWindow.h"
#include <QTableWidget>
#include <QGroupBox>
#include "UndoStack.h"

const int wasDeleted = 0;
const int wasEdit = 1;
const int wasAdd = 2;
class AddWindow;
class EditCarWindow;
class MainWindow: public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent);

    Tree<Wagon> wagonTree;
    Tree<Refrigerator> refrigTree;
    Tree<Tipper> tipperTree;
    Tree<OilCar> oilTree;

    QStringList *wagonsForDel;
    QStringList *refrigForDel;
    QStringList *tippersForDel;
    QStringList *oilCarsForDel;

    undoStack undoDelWag;
    undoStack undoDelRefrig;
    undoStack undoDelTipper;
    undoStack undoDelOil;
protected:
   void closeEvent(QCloseEvent *event);
   void contextMenuEvent(QContextMenuEvent *event);
   void resizeEvent(QResizeEvent *event);

private:
    AddWindow *edw;
    EditCarWindow *carEditWind;
    void createMenus();
    void createActions();
    void createToolBar();
    bool okToContinue();
    void createTables();
    void createMainLay();

    template <class TYPE>
    void createCarTable(QTableWidget *table);
    void createRefrigTable();

    template <class TYPE>
    Tree<TYPE> readCarFile(QString filename, Tree<TYPE> tree);

    template <class TYPE>
    bool writeCarToFile(QString filename, Tree<TYPE> tree);

    template <class TYPE>
    void addCarToTable(int curRow, TYPE obj, QTableWidget *table);

    template <class TYPE>
    void showCar(QTableWidget *table, Tree<TYPE> tree);

    template <class TYPE>
    void searchCar(QTableWidget *table);

    template <class TYPE>
    undoStack hideCar(QStringList *list, Tree<TYPE> tree, QTableWidget *table, int curRow, undoStack stack);

    template <class TYPE>
    Tree<TYPE> undoEditing(QString data, Tree<TYPE> tree);

    template <class TYPE>
    Tree<TYPE> undoActionsTemplate(undoStack *stack, Tree<TYPE> tree, QStringList *list);

    template <class TYPE>
    Tree<TYPE> deleteByList(QStringList *list, Tree<TYPE> tree);

    template <class TYPE>
    void editCar(int curRow, QTableWidget *table, undoStack *stack, QStringList *list);

    template <class TYPE>
    void conditionFilter(QTableWidget *table);

    bool saveFile(QString fileName, QString fileName1,
                  QString fileName2 ,QString fileName3);
    void readSettings();
    void writeSettings();
   // bool maybeSave();

    Wagon wagon;
    Refrigerator refrig;
    Tipper tipper;
    OilCar oilCar;

    QTableWidget *wagonTable;
    QTableWidget *refrigTable;
    QTableWidget *tipperTable;
    QTableWidget *oilCarTable;

    QString wagonFile;
    QString refrigFile;
    QString tipperFile;
    QString oilCarFile;

    QGroupBox *wagonBox;
    QGroupBox *refrigBox;
    QGroupBox *tipperBox;
    QGroupBox *oilCarBox;

    QLabel *locationLabel;
    QString curFile;

    QMenu *file;
    QMenu *edit;
    QMenu *tools;
    QMenu *help;

    QToolBar *fileToolBar;
    QToolBar *editToolBar;
    QToolBar *showToolBar;
    QToolBar *condToolBar;
    QToolBar *searchToolBar;

    QComboBox *showBox;
    QComboBox *condBox;

    QAction *newAct;
    QAction *openAct;
    QAction *saveAct;
    QAction *exitAct;

    QAction *undo;
    QAction *redo;

    QAction *addAct;
    QAction *editAct;
    QAction *deleteAct;

    QAction *helpAct;
    QAction *aboutAct;

    QLineEdit *searchArea;

    int tableActive;
signals:
    void writtenOffChoosen();
    void stackChanged();
private slots:
    void searchCar();
    void showTable();
    void refresh();

    void showCondFilter();
    void deleteCar();
    void editCarInfo();

    void add();
    bool save();
    void about();
    void somethingChanged();

    void deleteCarBeforeSaving();
    void undoAction();
    void setUndoEnabled();
public slots:
    void wagonActive();
    void refrigActive();
    void tipperActive();
    void oilCarActive();
};

#endif // MAINWINDOW_H
